let tasks = []
let currentId = 1;

// criar tarefa
const createTask = (id, title) => {
    return {
        id,
        title,
        completed: false
    }
} 
module.exports = { createTask }