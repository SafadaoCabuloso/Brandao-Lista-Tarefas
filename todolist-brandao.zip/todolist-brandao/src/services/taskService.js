const { createTask } = require('../models/taskModel');
const { title } = require('node:process'); // o usuario vai fazer um request do title, com isso resultando na nossa to do list

let tasks = [];
let idCounter = 1;

// criar
const addTask = (title) => {
    const task = createTask(idCounter++, title);
    tasks.push(task);
    return task;
}

// listar
const getTasks = () => tasks;

const getTaskById = (id) => {
    return tasks.find(t => t.id == id);
}

//atualizar
const updateTask = (id, title, completed) => {
    const task = tasks.find(t => t.id == id);
    if(!task) return null;

    if(task!==undefined) {
        task.title = title;
    }
    if(completed !==undefined) {
        task.completed = completed;
    }

    return task;
}

//deletar
const deleteTask = (id) => {
    const index = tasks.findIndex(t => t.id == id);
    if(index  === -1) return false;

    tasks.splice(index, 1);
    return true;
}

module.exports = {
    addTask,
    getTasks,
    getTaskById,
    updateTask,
    deleteTask
}