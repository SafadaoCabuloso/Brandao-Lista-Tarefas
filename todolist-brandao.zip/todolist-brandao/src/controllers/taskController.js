const taskService = require('../services/taskService');

//funcao auxiliar para ler body
const getRequestBody = (req) => {
    return new Promise((resolve, reject) => {
        let body = '';

        req.on('data', chunk => {
            body = body + chunk.toString();
        })

        req.on('end', () => {
        try {
             resolve(JSON.parse(body));
        } catch {
            resolve({});
        }
        })
    })
}

// cria tarefa
const createTask = async (req, res) => {
    const body = await getRequestBody(req);

    if(!body.title) {
        res.statusCode =  400;
        return res.end(JSON.stringify({ message: 'Titulo eh obrigatorio'}));
    }

    const task = taskService.addTask(body.title);

    res.statusCode = 201;
    res.end(JSON.stringify(task));
}

//listar tarefas
const listTasks = (req, res) => {
    const tasks = taskService.getTasks();

    res.statusCode = 200;
    res.end(JSON.stringify(tasks));
}

// pleno

const getTaskById = (req, res, id) => {
    const task = taskService.getTaskById(id);

    if(!task) {
        res.statusCode =404;
        return res.end(JSON.stringify({message: 'Nao encontrado'}))
    }
    res.end(JSON.stringify(task));
}

// atualizar tarefa
const updateTask = async (req, res, id) => {
    const body = await getRequestBody(req);

    const task = taskService.updateTask(id, body.title, body.completed);


    if (!task) {
        res.statusCode = 404;
        return res.end(JSON.stringify(
            { message: 'Nao encontrado'})
        )
    }

    res.end(JSON.stringify(task));
}

// deletar tarefa
const deleteTask = (req, res, id) => {
    const sucess = taskService.deleteTask(id);

    if (!sucess) {
        res.statusCode = 404;
        return res.end(JSON.stringify({message: 'Não encontrada'}))
    }

    res.end(JSON.stringify( {message: 'Removida'}))
}

module.exports = {
    createTask,
    listTasks,
    getTaskById,
    updateTask,
    deleteTask
}