const http = require('http');

//rotas
const taskRoutes = require('./routes/taskRoutes');

// servidro
const server = http.createServer((req, res) => {
    res.setHeader('Content-Type', 'application/json');
    taskRoutes(req, res);
})

// porta
const PORT = 3000;

// inicio servidor
server.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}, logo o link eh http://localhost:${PORT}`);
})